package com.prodapt.learningspring.exception;

public class NotLoggedInException extends RuntimeException {

    public NotLoggedInException(String message){

        super(message);

    }

}